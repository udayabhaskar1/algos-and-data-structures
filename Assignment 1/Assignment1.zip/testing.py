import time                                 # importing the time module to analyse the time efficiency of the various functions
import random                               # importing the random module to use random integers in different functions
from sparse_array import SparseArray        # accessing the SparseArray
import sys

n = int(input("Enter the size of the sequence : "))
m = int(input("Enter the number of non-empty cells in the sequence : "))
L = SparseArray(n)



def test_get():
    """
    Used to calculate the time taken to get an item from the Sparse Array
    :return: Nothing, prints the average of the running times taken to give an accurate measure
    """

    running_time = []                               # initialising running time as an empty list
    num = random.randint(0,m)                       # using a random integer value between 0 and m
    for i in range(5):

        start_time = time.clock()                   # checking the start time
        L.__getitem__(num)                          # running the getitem method to get an item
        elapsed_time = time.clock() - start_time    # checking the time taken to get the item

        print("-{}- running time (%.3f microseconds)".format(i + 1) % (elapsed_time * 1000000))
        running_time.append(elapsed_time * 1000000)

    print("\nAverage running time to get an item ---> ({0:.3f} microseconds)"'\n'.format(sum(running_time) / 5))

def test_set():
    """
    Used to calculate the time taken to set an element at an index in the Sparse Array
    :return: Nothing, prints the average of the running times taken to give an accurate measure
    """

    running_time = []                               # initialising running time as an empty list

    j = random.randint(0, n)                        # index of the node should be a number between 0 and n
    e = random.randint(1, 100)                      # setting a random number, can be set to anything


    for i in range(5):

        start_time = time.clock()
        L.__setitem__(j,e)
        elapsed_time = time.clock() - start_time

        print("-{}- running time (%.3f microseconds)".format(i + 1) % (elapsed_time * 1000000))
        running_time.append(elapsed_time * 1000000)

    print("\nAverage running time to set an item ---> ({0:.3f} microseconds)"'\n'.format(sum(running_time) / 5))

def test_get_python_list():
    """
    This function is used to calculate the time taken to access an item in a normal python list
    :return: Nothing, just prints the average running time
    :return:
    """

    running_time = []                                               # initialising running time as an empty list

    python_list = [random.randint(1, 100) for y in range(n)]        # create a python list of size n
    num = random.randint(0,n)                                       # generate a random number between 0 and n as index

    for i in range(5):
        start_time = time.clock()
        python_list[num]                                            # access the element from the python list
        elapsed_time = time.clock() - start_time

        print("-{}- running time (%.3f microseconds)".format(i + 1) % (elapsed_time * 1000000))
        running_time.append(elapsed_time * 1000000)

    print("\nMemory size of the python list: ",sys.getsizeof(python_list))
    print("\nAverage running time to get an item from a python list ---> ({0:.3f} microseconds)"'\n'.format(sum(running_time) / 5))


def test_set_python_list():
    """
    This function is used to calculate the time taken to insert an item in a normal python list
    :return: Nothing, just prints the average running time
    """

    running_time = []                                               # initialising running time as an empty list

    python_list = [random.randint(1, 100) for y in range(n)]        # create a python list of size n
    num = random.randint(1, 100)                                    # generate a random number as element
    index = random.randint(0, n)                                    # generate a random number as index

    for i in range(5):

        start_time = time.clock()
        python_list.insert(index,num)
        elapsed_time = time.clock() - start_time

        print("-{}- running time (%.3f microseconds)".format(i + 1) % (elapsed_time * 1000000))
        running_time.append(elapsed_time * 1000000)

    print("\nMemory size of the python list: ",sys.getsizeof(python_list))
    print("\nAverage running time to set an item from a python list ---> ({0:.3f} microseconds)"'\n'.format(sum(running_time) / 5))


def create_sequence(m,n):
    """
    Generating a sequence with non empty cells at random locations in a list.
    The total size of the list is set to n
    The number of non-empty cells is m
    We are using a random numbers(from 1 to 100) to fill in the non-empty cells

    :param m: Number of non-empty cells in the Sequence
    :param n: Size of the Sequence
    :return: Sequence list with non-empty elements and None values
    """

    L = SparseArray(n)
    first_list = [None for x in range(n)]                       # creates a list of size n with all None values
    second_list = [random.randint(1, 100) for y in range(m)]    # creates a list of size m with all random values


    count = 0                                                   # Setting the initial value to count the number of non-empty cells in the list
    while count != m:
        for index, z in enumerate(first_list):
            if random.randint(0, 1):                            # produces 0 or 1 at random, 0 means 'False', dont fill the cell, 1 meeans 'True'
                first_list[index] = random.choice(second_list)
                count += 1
                if count == m:                                  # if the non-empty cells is equal to the value m, break.
                    break
        print("\nGenerating the Sequence... \n\n",first_list)
        return first_list                                       # returns the sequence with non-empty cells and None values

L.fill(create_sequence(m,n))
print("\nPrinting the Linked List... \n")
print(L)
print("\nCalculating the running times...\n\nRunning times to get an item\n")
test_get()
print("Running times to set an item\n")
test_set()
print("\nRunning times to get an item from a python list\n")
test_get_python_list()
print("\nRunning times to set an item in a python list\n")
test_set_python_list()


print("Length of the Sparse Array: ",len(L))
print("Number of non-empty elements in the Sparse Array: ", L._usage)
print("Element at index 0 is ", L[0])




