"""
This program is an implementation of the Sparse Array using a singly linked list. It is developed as part
of an assessment for the subject module CP2410 - Algorithms and Data Structures

Student Name: Udaya Bhaskar Reddy Malkannagari
Student ID: 13368171
Version: 1.0
"""

class SparseArray:
    """SparseArray implementation using linked list for storage"""
    class Node:
        """Lightweight, nonpublic class for storing a singly linked node."""

        def __init__(self, e=None, next=None):  # initialize node's fields (default values set to None)
            self.e = e                          # reference to user's element
            self.next = next                    # reference to next node

        def __str__(self):
            """
            Used to print the element in the node
            :return: element
            """
            return str(self.e)

    def __init__(self, n, head=None):
        """Create an empty Sparse Array"""
        self._size = n                          # No of elements in the SparseArray(equal to n)
        self._head = head                       # reference to the head node
        self._usage = 0                         # access non-empty elements in the SparseArray, initially set to 0

    def __str__(self):
        """
        Used to print the values of the Sparse Array to ensure that the values re linking correctly
        :return: Formatted list values
        """

        current_node = self._head
        linked_list = []                        # initialising an empty linked list
        while current_node:                     # appending each element with its reference to the linked list
            linked_list.append("Index : {}, Element : {}, Reference to next node : {}".format(current_node.e[0], current_node.e[1], current_node.next))
            current_node = current_node.next
        return str(linked_list)

    def __len__(self):
        """Return the number of elements in the Sparse Array"""
        return self._size

    def fill(self, seq):
        """
        Used to detect if element in sequence is None or not
        :param seq: takes a list as input
        :return: does not return anything,logically moves to the self._setitem_ function to fill in the elements
        """

        if not isinstance(seq, list):           # checking if the imput sequence is a list
            raise TypeError("I only accepts lists, please do not put anything else in me")

        count = 0

        if len(seq) > self._size:               # checking if the length of the sequence is greater than the size of the Sparse array
            raise IndexError                    # Raising an index error if the length of the seq is greater
        for elem in seq:
            if elem is None:
                pass
            else:
                self.__setitem__(count, elem)
                count += 1
                self._usage += 1                # adding the count of non-empty values in the Sparse array

    def __setitem__(self, j, e):
        """
        Populate the Node of the Linked list with value and index
        :param j: index
        :param e: value
        :return: does not return anything
        """

        if j < 0:
            j += self._size
        elif j >= self._size:
            raise IndexError

        self._head = self.Node([j, e], self._head)      # create and link a new node
        #self._size += 1


    def __getitem__(self, j):
        """
        Takes an index of sequence as input parameter and traverse the linked list nodes,
        matches the index of each node with the input parameter and retrieves the corresponding value when index matches
        :param j: index of the sequence
        :return: does not return anything
        """
        if j < 0:
            j += self._size
        elif j >= self._size:                           # raise index error for wrong inputs
            raise IndexError
        elif not self._head or len(self) < j:
            raise IndexError

        current_node = self._head
        while current_node:
            if current_node.e[0] == j:
                return current_node.e[1]
            current_node = current_node.next
