"""
this program is used to test the time complexity of the AVL tree
"""

import time
from avl_tree import AVLTreeMap

student_dict = {13368171: "Uday", 13354612: "Albert", 13345678: "Lisha",
                13345789: "Sharath", 13345890: "Susan", 13345202: "Samantha", 13321111: "Francesca", 13321212: "Jin",
                13312121: "Vinay", 13312456: "Sudheer", 13358717: "Sandeep"}

print("Calculating the Efficiency for inserting items into the AVL Tree on several runs...\n")

"""
FIRST EXPERIMENT, AVL Tree is empty
"""
print("-------------------------------------------------------------------------------------------------------")
print("FIRST EXPERIMENT, AVL tree with no nodes...\n\n\nExperiment 1 (AVL tree with no initial nodes: )")
experiment1 = AVLTreeMap()
i = 0
running_time_one = []
start_overall = time.clock()
for key,value in student_dict.items():
    start = time.clock()
    experiment1.__setitem__(key, value)
    elapsed_time = time.clock() - start
    print("Efficiency to set item {}- running time (%.3f microseconds)".format(i) % (elapsed_time * 1000000))
    i += 1
    running_time_one.append(elapsed_time * 1000000)

elapsed_time_overall = time.clock() - start_overall
print("\nAverage running time to set an item into the AVL Tree---> ({0:.3f} microseconds)".format(sum(running_time_one) / i))
print("Total time to insert all the items: {0:.3f} microseconds".format(elapsed_time_overall * 1000000))


"""
GET ITEM, Searching for an item in the AVL tree
"""
print("-------------------------------------------------------------------------------------------------------")
print("GET ITEM, Searching for an item in the AVL Tree")
i = 0
running_time_get = []
for i in range(5):
    start_time = time.clock()
    experiment1.__getitem__(13368171)
    elapsed_time = time.clock() - start_time
    print("-{}- running time (%.3f microseconds)".format(i + 1) % (elapsed_time * 1000000))
    running_time_get.append(elapsed_time * 1000000)

print("\nAverage running time to get an item from the AVL tree---> ({0:.3f} microseconds)"'\n'.format(sum(running_time_get) / 5))

"""
DELETE ITEM, Deleting an item from the AVL tree
"""

print("-------------------------------------------------------------------------------------------------------")
print("DELETE ITEM, Searching for an item in the AVL Tree")
running_time_del = []
start_time_del = time.clock()
experiment1.__delitem__(13368171)
elapsed_time_del = time.clock() - start_time_del
print("Running time to delete an item : {0:.3f} microseconds".format(elapsed_time_del * 1000000))


"""
SECOND EXPERIMENT, AVL Tree with three nodes
"""
print("-------------------------------------------------------------------------------------------------------")
print("SECOND EXPERIMENT, AVL tree with three nodes\n\n\nExperiment 2 : AVL Tree with three nodes")
experiment2 = AVLTreeMap()
experiment2.__setitem__(13368171, "Uday")
experiment2.__setitem__(13354612, "Albert")
experiment2.__setitem__(13345678, "Lisha")
i = 0
running_time_one = []
start_overall = time.clock()
for key,value in student_dict.items():
    start = time.clock()
    experiment2.__setitem__(key, value)
    elapsed_time = time.clock() - start
    print("Efficiency to set item {}- running time (%.3f microseconds)".format(i) % (elapsed_time * 1000000))
    i += 1
    running_time_one.append(elapsed_time * 1000000)

elapsed_time_overall = time.clock() - start_overall
print("\nAverage running time to set an item into the AVL Tree---> ({0:.3f} microseconds)".format(sum(running_time_one) / i))
print("Total time to insert all the items: {0:.3f} microseconds".format(elapsed_time_overall * 1000000))

