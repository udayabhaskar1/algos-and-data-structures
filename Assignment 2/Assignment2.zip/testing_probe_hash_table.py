"""
This program is used to test the time complexity of the Probing hash table
"""

import time
from probe_hash_map import ProbeHashMap


student_dict = {13368171: "Uday", 13354612: "Albert", 13345678: "Lisha",
                13345789: "Sharath", 13345890: "Susan", 13345202: "Samantha", 13321111: "Francesca", 13321212: "Jin",
                13312121: "Vinay", 13312456: "Sudheer", 13358717: "Sandeep"}

print("Calculating the Efficiency for inserting items into the Hash Table on several runs...\n\n")

"""
FIRST EXPERIMENT, bucket array is empty
"""
print("-------------------------------------------------------------------------------------------------------")
print("FIRST EXPERIMENT, bucket array is empty...\n\nLoad Factor = 0/11\n\nExperiment 1 (Empty bucket array: )")
experiment1 = ProbeHashMap()
print(experiment1)
i = 0
running_time_one = []
start_overall = time.clock()
for key,value in student_dict.items():
    start = time.clock()
    experiment1._bucket_setitem(i, key, value)
    elapsed_time = time.clock() - start
    print("Efficiency to set item {}- running time (%.3f microseconds)".format(i) % (elapsed_time * 1000000))
    i += 1
    running_time_one.append(elapsed_time * 1000000)

elapsed_time_overall = time.clock() - start_overall
print("\nAverage running time to set an item into the bucket array---> ({0:.3f} microseconds)".format(sum(running_time_one) / i))
print("Total time to insert all the items: {0:.3f} microseconds".format(elapsed_time_overall * 1000000))
print("\nAfter inserting the items...\n")
print(experiment1)
print("Hash value for student id 13368171 is ",experiment1._hash_function(13368171))
print("Hash value for student id 13345678 is ",experiment1._hash_function(13345678))

"""
GET ITEM,Calculating the running time to get an item from the bucket array
"""
print("-------------------------------------------------")
print("\nGET ITEM...\nCalculating the running time to get an item...")
running_time_get = []
for i in range(5):
    start_time = time.clock()
    experiment1._bucket_getitem(0,13368171)
    elapsed_time = time.clock() - start_time
    print("-{}- running time (%.3f microseconds)".format(i + 1) % (elapsed_time * 1000000))
    running_time_get.append(elapsed_time * 1000000)

print("\nAverage running time to get an item ---> ({0:.3f} microseconds)"'\n'.format(sum(running_time_get) / 5))

"""
DELETE ITEM, Calculating the running time to delete an item from the bucket array
"""

print("-------------------------------------------------")
print("DELETE ITEM...\nCalculating the running time to delete an item...")
running_time_del = []
start_time_del = time.clock()
experiment1._bucket_delitem(1,13354612)
elapsed_time_del = time.clock() - start_time_del
print("Running time to delete an item : {0:.3f} microseconds".format(elapsed_time_del * 1000000))

"""
SECOND EXPERIMENT, bucket array is full by more than 50%, Load Factor greater than 0.5
"""
print("-------------------------------------------------------------------------------------")
print("SECOND EXPERIMENT, bucket array is full by more than 50%...\n\nLoad Factor = 6/11\n")
experiment2 = ProbeHashMap()
experiment2.__setitem__(13368172, "Reddy")
experiment2.__setitem__(13354613, "Daniel")
experiment2.__setitem__(13345679, "Delha")
experiment2.__setitem__(13345780, "Sarnath")
experiment2.__setitem__(13345891, "Lahan")
experiment2.__setitem__(13345203, "Amanda")

running_time_two = []
i = 0
start_overall = time.clock()
for key,value in student_dict.items():
    start = time.clock()
    experiment2._bucket_setitem(i, key, value)
    elapsed_time = time.clock() - start
    print("Efficiency to set item {}- running time (%.3f microseconds)".format(i) % (elapsed_time * 1000000))
    i += 1
    running_time_two.append(elapsed_time * 1000000)

elapsed_time_overall = time.clock() - start_overall
print("\nAverage running time to set an item into the bucket array---> ({0:.3f} microseconds)".format(sum(running_time_two) / i))
print("\nEfficiency to set overall time: {0:.3f} microseconds".format(elapsed_time_overall * 1000000))
print("\nAfter inserting the items...\n")
print(experiment2)

print("-------------------------------------------------")
print("\nGET ITEM...\nCalculating the running time to get an item...")
running_time_get = []
for i in range(5):
    start_time = time.clock()
    experiment1._bucket_getitem(0,13368171)
    elapsed_time = time.clock() - start_time
    print("-{}- running time (%.3f microseconds)".format(i + 1) % (elapsed_time * 1000000))
    running_time_get.append(elapsed_time * 1000000)

print("\nAverage running time to get an item ---> ({0:.3f} microseconds)"'\n'.format(sum(running_time_get) / 5))



"""
THIRD EXPERIMENT - Bucket array is full by less than 50%, load factor is less than 0.5
"""
print("----------------------------------------------------------------------")
print("Third experiment, bucket array is 1/4 full...\n\nLoad factor = 3/11\n")
experiment3 = ProbeHashMap()
experiment3.__setitem__(13368177, "Shanit")
experiment3.__setitem__(13354618, "Shiva")
experiment3.__setitem__(13345679, "Shankar")
print(experiment3)

running_time_three = []
i = 3
start_overall = time.clock()
for key,value in student_dict.items():
    start = time.clock()
    experiment3._bucket_setitem(i,key, value)
    elapsed_time = time.clock() - start
    print("Efficiency to set item {}- running time (%.3f microseconds)".format(i) % (elapsed_time * 1000000))
    i += 1
    running_time_three.append(elapsed_time * 1000000)
    if i == 11:
        break
elapsed_time_overall = time.clock() - start_overall
print("\nAverage running time to set an item into the bucket array---> ({0:.3f} microseconds)".format(sum(running_time_three) / 8))
print("\nEfficiency to set overall time: {0:.3f} microseconds".format(elapsed_time_overall * 1000000))
print(experiment3)



"""
FOURTH EXPERIMENT, last index is empty...
"""
print("--------------------------------------------------------")
print("FOURTH EXPERIMENT, Same entries\n\nLoad Factor = 3/11\n")
experiment4 = ProbeHashMap()
experiment4.__setitem__(13368171, "Uday")
experiment4.__setitem__(13354612, "Albert")
experiment4.__setitem__(13345678, "Lisha")
print(experiment4)

running_time_four = []
i = 3
start_overall = time.clock()
for key,value in student_dict.items():
    start = time.clock()
    experiment4._bucket_setitem(i, key, value)
    elapsed_time = time.clock() - start
    print("Efficiency to set item {}- running time (%.3f microseconds)".format(i) % (elapsed_time * 1000000))
    i += 1
    running_time_four.append(elapsed_time * 1000000)
    if i == 11:
        break

elapsed_time_overall = time.clock() - start_overall
print("\nAverage running time to set an item into the bucket array---> ({0:.3f} microseconds)".format(sum(running_time_four) / 8))
print("\nEfficiency to set overall time: {0:.3f} microseconds".format(elapsed_time_overall * 1000000))
print("\nAfter insertion...\n")
print(experiment4)





